package com.example.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.ui.theme.*
import com.example.viewmodel.CctvViewModel
import org.webrtc.EglBase
import org.webrtc.RendererCommon
import org.webrtc.SurfaceViewRenderer
import org.webrtc.VideoTrack

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ViewerScreen(viewModel: CctvViewModel) {
    val connectionDeviceId by viewModel.connectionDeviceId.collectAsState()
    val connectionPin by viewModel.connectionPin.collectAsState()
    val isConnecting by viewModel.isConnecting.collectAsState()
    val viewerConnected by viewModel.viewerConnected.collectAsState()

    val remoteBattery by viewModel.remoteBattery.collectAsState()
    val remoteNetwork by viewModel.remoteNetwork.collectAsState()
    val connectionQuality by viewModel.connectionQuality.collectAsState()
    val latencyMs by viewModel.latencyMs.collectAsState()
    val remoteVideoTrack by viewModel.remoteVideoTrack.collectAsState()

    var isFullscreen by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(CleanBg)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(if (isFullscreen) 0.dp else 16.dp),
            verticalArrangement = if (isFullscreen) Arrangement.Top else Arrangement.spacedBy(16.dp)
        ) {
            // Header (Omitted if fullscreen)
            if (!isFullscreen) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Viewer Monitor",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = DarkText
                    )
                    
                    if (viewerConnected) {
                        IconButton(onClick = { viewModel.disconnectViewer() }) {
                            Icon(
                                imageVector = Icons.Rounded.Close,
                                contentDescription = "Terminate ongoing stream session",
                                tint = RedStopButton
                            )
                        }
                    }
                }
            }

            // Connection Setup (if not connected)
            if (!viewerConnected) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .animateContentSize(),
                    colors = CardDefaults.cardColors(containerColor = SurfaceVariant),
                    border = BorderStroke(1.dp, BorderColor),
                    shape = RoundedCornerShape(24.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Monitor,
                                contentDescription = "Pair monitor layout screen panel",
                                tint = Purple40
                            )
                            Text(
                                text = "Pair with CCTV Camera",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = DarkText
                            )
                        }

                        Text(
                            text = "Enter the CCTV Device ID and 6-digit connection PIN generated on the streaming device below.",
                            fontSize = 13.sp,
                            color = GrayText
                        )

                        // Device ID Input
                        OutlinedTextField(
                            value = connectionDeviceId,
                            onValueChange = { viewModel.setConnectionDeviceId(it) },
                            label = { Text("Device ID (e.g. CAM-9942)") },
                            singleLine = true,
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("viewer_device_id_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Purple40,
                                unfocusedBorderColor = BorderColor
                            )
                        )

                        // Connection PIN Input
                        OutlinedTextField(
                            value = connectionPin,
                            onValueChange = { viewModel.setConnectionPin(it) },
                            label = { Text("6-Digit PIN") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("viewer_pin_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Purple40,
                                unfocusedBorderColor = BorderColor
                            )
                        )

                        // Trigger Connect button
                        Button(
                            onClick = { viewModel.connectToCctvDevice() },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .testTag("viewer_connect_button"),
                            shape = CircleShape,
                            colors = ButtonDefaults.buttonColors(containerColor = Purple40),
                            enabled = !isConnecting && connectionDeviceId.isNotEmpty() && connectionPin.isNotEmpty()
                        ) {
                            if (isConnecting) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(24.dp),
                                    color = Color.White,
                                    strokeWidth = 2.dp
                                )
                            } else {
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Link,
                                        contentDescription = "Trigger pairing connection negotiation link"
                                    )
                                    Text("Pair & Secure Connection")
                                }
                            }
                        }
                    }
                }
            } else {
                // Connected stream render area
                val feedHeightModifier = if (isFullscreen) Modifier.fillMaxSize() else Modifier
                    .weight(1f)
                    .fillMaxWidth()

                Box(
                    modifier = feedHeightModifier
                        .clip(if (isFullscreen) RoundedCornerShape(0.dp) else RoundedCornerShape(24.dp))
                        .background(Color.Black)
                        .border(
                            width = if (isFullscreen) 0.dp else 1.dp,
                            color = BorderColor.copy(alpha = 0.5f),
                            shape = RoundedCornerShape(24.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    // WebRTC video track render
                    if (remoteVideoTrack != null) {
                        WebRtcSurfaceRenderer(
                            videoTrack = remoteVideoTrack!!,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        // Standing by placeholder inside connection box
                        Text(
                            text = "Waiting for Camera frame stream feed...",
                            color = Color.White.copy(alpha = 0.5f),
                            fontSize = 13.sp
                        )
                    }

                    // Feed overlay tags
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp)
                    ) {
                        // Top Left Overlays (Live badge & battery)
                        Row(
                            modifier = Modifier.align(Alignment.TopStart),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                modifier = Modifier
                                    .clip(CircleShape)
                                    .background(Color.Black.copy(alpha = 0.5f))
                                    .border(1.dp, Color.White.copy(alpha = 0.2f), CircleShape)
                                    .padding(horizontal = 12.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(Color.Green)
                                )
                                Text(
                                    text = "LIVE FEED",
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 0.5.sp
                                )
                            }

                            Row(
                                modifier = Modifier
                                    .clip(CircleShape)
                                    .background(Color.Black.copy(alpha = 0.5f))
                                    .border(1.dp, Color.White.copy(alpha = 0.2f), CircleShape)
                                    .padding(horizontal = 12.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Battery5Bar,
                                    contentDescription = "Battery capacity indicator",
                                    tint = Color.White,
                                    modifier = Modifier.size(12.dp)
                                )
                                Text(
                                    text = "$remoteBattery% CAM",
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        // Top Right Overlays (Network Quality & Latency metrics)
                        Row(
                            modifier = Modifier.align(Alignment.TopEnd),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                modifier = Modifier
                                    .clip(CircleShape)
                                    .background(Color.Black.copy(alpha = 0.5f))
                                    .border(1.dp, Color.White.copy(alpha = 0.2f), CircleShape)
                                    .padding(horizontal = 12.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.RssFeed,
                                    contentDescription = "CCTV ping delay stream quality indicator meter",
                                    tint = Color.White,
                                    modifier = Modifier.size(12.dp)
                                )
                                Text(
                                    text = "${latencyMs}ms ($connectionQuality)",
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            // Fullscreen icon
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(Color.Black.copy(alpha = 0.5f))
                                    .border(1.dp, Color.White.copy(alpha = 0.2f), CircleShape)
                                    .clickable { isFullscreen = !isFullscreen },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (isFullscreen) Icons.Rounded.FullscreenExit else Icons.Rounded.Fullscreen,
                                    contentDescription = "Toggle full-screen viewing format layout",
                                    tint = Color.White,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }

                        // Bottom Overlay (Device detail identifiers)
                        Column(
                            modifier = Modifier.align(Alignment.BottomStart),
                            verticalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            Text(
                                text = "MONITORING CCTV NODE",
                                color = Color.White.copy(alpha = 0.7f),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold,
                                letterSpacing = 0.5.sp
                            )
                            Text(
                                text = "NODE ID: $connectionDeviceId",
                                color = Color.White,
                                fontSize = 14.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            }

            // Remote control panel (Omitted if fullscreen)
            if (!isFullscreen && viewerConnected) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Card(
                        modifier = Modifier.weight(1f),
                        colors = CardDefaults.cardColors(containerColor = PurpleCardBg),
                        shape = RoundedCornerShape(24.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Security,
                                contentDescription = "Secure status flag badge icon",
                                tint = PurpleCardText
                            )
                            Text(
                                text = "Encryption status",
                                color = PurpleCardText.copy(alpha = 0.7f),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                text = "End-to-End P2P",
                                color = PurpleCardText,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Card(
                        modifier = Modifier.weight(1f),
                        colors = CardDefaults.cardColors(containerColor = SurfaceVariant),
                        shape = RoundedCornerShape(24.dp),
                        border = BorderStroke(1.dp, BorderColor)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Wifi,
                                contentDescription = "Network protocol speed category metadata",
                                tint = GrayText
                            )
                            Text(
                                text = "Negotiated link protocol",
                                color = GrayText.copy(alpha = 0.7f),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                text = remoteNetwork,
                                color = DarkText,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Button(
                    onClick = { viewModel.disconnectViewer() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .testTag("terminate_viewer_connection_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = RedStopButton),
                    shape = CircleShape
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.PowerSettingsNew,
                            contentDescription = "Terminate monitor session screen connection"
                        )
                        Text(
                            text = "Disconnect Stream Session",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun WebRtcSurfaceRenderer(
    videoTrack: VideoTrack,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val eglContext = remember { EglBase.create().eglBaseContext }
    
    val renderer = remember {
        SurfaceViewRenderer(context).apply {
            init(eglContext, null)
            setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FIT)
            setEnableHardwareScaler(true)
        }
    }

    DisposableEffect(videoTrack) {
        videoTrack.addSink(renderer)
        onDispose {
            try {
                videoTrack.removeSink(renderer)
                renderer.release()
            } catch (e: Exception) {
                // Ignore silent release
            }
        }
    }

    AndroidView(
        factory = { renderer },
        modifier = modifier
    )
}
