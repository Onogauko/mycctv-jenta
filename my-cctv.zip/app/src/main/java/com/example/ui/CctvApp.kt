package com.example.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AppMode
import com.example.ui.theme.*
import com.example.viewmodel.CctvViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CctvApp(viewModel: CctvViewModel) {
    val appMode by viewModel.appMode.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(Purple40),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Security,
                                contentDescription = "Logo",
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Text(
                            text = "My CCTV",
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp,
                            color = DarkText
                        )
                    }
                },
                navigationIcon = {
                    if (appMode != AppMode.Idle) {
                        IconButton(
                            onClick = { viewModel.selectAppMode(AppMode.Idle) },
                            modifier = Modifier.testTag("app_back_button")
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.ArrowBack,
                                contentDescription = "Navigate backward to main menu mode",
                                tint = GrayText
                            )
                        }
                    }
                },
                actions = {
                    IconButton(onClick = {}) {
                        Icon(
                            imageVector = Icons.Rounded.AccountCircle,
                            contentDescription = "User account indicators",
                            tint = GrayText
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = CleanBg,
                    titleContentColor = DarkText
                )
            )
        },
        bottomBar = {
            if (appMode != AppMode.Idle) {
                Surface(
                    color = SurfaceVariant,
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, BorderColor.copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceAround,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Camera Tab option
                        Column(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .clickable { viewModel.selectAppMode(AppMode.Device) }
                                .padding(horizontal = 24.dp, vertical = 6.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            val isSelected = appMode == AppMode.Device
                            Box(
                                modifier = Modifier
                                    .clip(CircleShape)
                                    .background(if (isSelected) PurpleCardBg else Color.Transparent)
                                    .padding(horizontal = 20.dp, vertical = 6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Videocam,
                                    contentDescription = "Camera stream setup panel options",
                                    tint = if (isSelected) PurpleCardText else GrayText
                                )
                            }
                            Text(
                                text = "Camera",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) PurpleCardText else GrayText,
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }

                        // Monitor Tab option
                        Column(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .clickable { viewModel.selectAppMode(AppMode.Viewer) }
                                .padding(horizontal = 24.dp, vertical = 6.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            val isSelected = appMode == AppMode.Viewer
                            Box(
                                modifier = Modifier
                                    .clip(CircleShape)
                                    .background(if (isSelected) PurpleCardBg else Color.Transparent)
                                    .padding(horizontal = 20.dp, vertical = 6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Monitor,
                                    contentDescription = "Viewer monitor streams panel options",
                                    tint = if (isSelected) PurpleCardText else GrayText
                                )
                            }
                            Text(
                                text = "Monitor",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) PurpleCardText else GrayText,
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }
                    }
                }
            }
        },
        containerColor = CleanBg
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            AnimatedContent(
                targetState = appMode,
                transitionSpec = {
                    fadeIn(animationSpec = tween(300)) togetherWith fadeOut(animationSpec = tween(250))
                },
                label = "ScreenSwitchingContent"
            ) { mode ->
                when (mode) {
                    AppMode.Idle -> IdleSelectionView(onSelectMode = { viewModel.selectAppMode(it) })
                    AppMode.Device -> DeviceScreen(viewModel = viewModel)
                    AppMode.Viewer -> ViewerScreen(viewModel = viewModel)
                }
            }
        }
    }
}

@Composable
fun IdleSelectionView(onSelectMode: (AppMode) -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = Icons.Rounded.CellTower,
            contentDescription = "Transmission tower decoration",
            tint = Purple40,
            modifier = Modifier
                .size(80.dp)
                .padding(bottom = 16.dp)
        )

        Text(
            text = "Welcome to My CCTV",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = DarkText,
            textAlign = TextAlign.Center
        )

        Text(
            text = "Turn this phone into a CCTV camera broadcast node, or monitor a remote camera live in real time.",
            fontSize = 14.sp,
            color = GrayText,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 8.dp, bottom = 40.dp)
        )

        // Select Camera Mode Card Option
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onSelectMode(AppMode.Device) }
                .testTag("select_camera_mode_card"),
            colors = CardDefaults.cardColors(containerColor = PurpleCardBg),
            shape = RoundedCornerShape(24.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(Color.White),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Videocam,
                        contentDescription = "Set up CCTV camera mode option logo",
                        tint = PurpleCardText
                    )
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Act as CCTV Device",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = PurpleCardText
                    )
                    Text(
                        text = "Broadcasting back camera and audio streams safely.",
                        fontSize = 13.sp,
                        color = PurpleCardText.copy(alpha = 0.7f)
                    )
                }
                Icon(
                    imageVector = Icons.Rounded.ChevronRight,
                    contentDescription = "Select option detail chevron icon",
                    tint = PurpleCardText
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Select Monitor Mode Card Option
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onSelectMode(AppMode.Viewer) }
                .testTag("select_monitor_mode_card"),
            colors = CardDefaults.cardColors(containerColor = SurfaceVariant),
            shape = RoundedCornerShape(24.dp),
            border = BorderStroke(1.dp, BorderColor)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(Color.White),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Monitor,
                        contentDescription = "Set up CCTV Viewer mode option logo",
                        tint = DarkText
                    )
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Act as Viewer Monitor",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = DarkText
                    )
                    Text(
                        text = "Pair and securely play remote feeds securely.",
                        fontSize = 13.sp,
                        color = GrayText
                    )
                }
                Icon(
                    imageVector = Icons.Rounded.ChevronRight,
                    contentDescription = "Select option detail chevron icon",
                    tint = GrayText
                )
            }
        }
    }
}
