package com.example.ui.components

import android.Manifest
import android.content.Context
import android.os.Build
import android.util.Log
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.data.SessionState
import com.example.firebase.FirebaseHelper
import com.example.service.CCTVForegroundService
import com.example.viewmodel.DeviceViewModel
import com.example.viewmodel.ViewerViewModel
import org.webrtc.EglBase
import org.webrtc.RendererCommon
import org.webrtc.SurfaceViewRenderer
import org.webrtc.VideoTrack

// Creative Direction Dark Color Palette
val MidnightGray = Color(0xFF0F1318)
val DarkCardBg = Color(0xFF161C24)
val NeonTeal = Color(0xFF00F2FE)
val NeonAmber = Color(0xFFFFAE00)
val NeonGreen = Color(0xFF10E274)
val CyberPunkRed = Color(0xFFFF2A5F)
val IceBlue = Color(0xFFE3F2FD)

@Composable
fun PremiumCCTVTopBar(
    title: String,
    onBack: (() -> Unit)? = null
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(56.dp)
            .background(MidnightGray)
            .padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onBack != null) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Return",
                    tint = Color.White
                )
            }
        } else {
            Spacer(modifier = Modifier.width(16.dp))
        }
        Text(
            text = title,
            color = Color.White,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
fun CCTVMasterApp(
    deviceViewModel: DeviceViewModel,
    viewerViewModel: ViewerViewModel
) {
    var currentScreen by remember { mutableStateOf("selector") } // "selector", "device", "viewer"
    val isFirebaseReady = FirebaseHelper.isReady()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MidnightGray)
    ) {
        AnimatedContent(
            targetState = currentScreen,
            transitionSpec = {
                slideInHorizontally { width -> width } + fadeIn() togetherWith
                        slideOutHorizontally { width -> -width } + fadeOut()
            },
            label = "ScreenTransition"
        ) { screen ->
            when (screen) {
                "selector" -> WelcomeSelectorScreen(
                    isFirebaseReady = isFirebaseReady,
                    onNavigateToDevice = { currentScreen = "device" },
                    onNavigateToViewer = { currentScreen = "viewer" }
                )
                "device" -> CCTVDeviceScreen(
                    viewModel = deviceViewModel,
                    onBack = { currentScreen = "selector" }
                )
                "viewer" -> CCTVViewerScreen(
                    viewModel = viewerViewModel,
                    onBack = { currentScreen = "selector" }
                )
            }
        }
    }
}

@Composable
fun WelcomeSelectorScreen(
    isFirebaseReady: Boolean,
    onNavigateToDevice: () -> Unit,
    onNavigateToViewer: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
            .navigationBarsPadding()
            .statusBarsPadding(),
        verticalArrangement = Arrangement.SpaceBetween,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // App Identity Header
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(top = 40.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .background(
                        Brush.linearGradient(listOf(NeonTeal, NeonGreen)),
                        CircleShape
                    )
                    .border(2.dp, Color.White.copy(alpha = 0.6f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Videocam,
                    contentDescription = "My CCTV",
                    tint = MidnightGray,
                    modifier = Modifier.size(45.dp)
                )
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            Text(
                text = "MY CCTV",
                color = Color.White,
                fontSize = 32.sp,
                fontWeight = FontWeight.ExtraBold,
                fontFamily = FontFamily.SansSerif,
                textAlign = TextAlign.Center
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Text(
                text = "Secured Peer-to-Peer Home Monitoring",
                color = Color.LightGray,
                fontSize = 14.sp,
                textAlign = TextAlign.Center
            )
        }

        // Main Selection Area
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // CCTV Device Card
            Card(
                onClick = onNavigateToDevice,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("device_mode_button"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkCardBg),
                elevation = CardDefaults.cardElevation(8.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(56.dp)
                            .background(NeonTeal.copy(alpha = 0.15f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Sensors,
                            contentDescription = "Camera Streamer",
                            tint = NeonTeal,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text(
                            text = "Camera Device Mode",
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Register as a live CCTV feed and broadcast rear camera over WebRTC.",
                            color = Color.Gray,
                            fontSize = 12.sp
                        )
                    }
                }
            }

            // CCTV Viewer Card
            Card(
                onClick = onNavigateToViewer,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("viewer_mode_button"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkCardBg),
                elevation = CardDefaults.cardElevation(8.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(56.dp)
                            .background(NeonAmber.copy(alpha = 0.15f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Tv,
                            contentDescription = "Monitor Streamer",
                            tint = NeonAmber,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text(
                            text = "Remote Viewer Mode",
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Enter Device ID & PIN to stream video & audio from anywhere.",
                            color = Color.Gray,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }

        // Connection Infrastructure Footer
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(20.dp))
                .background(Color.White.copy(alpha = 0.05f))
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .background(if (isFirebaseReady) NeonGreen else NeonAmber, CircleShape)
                )
                Text(
                    text = if (isFirebaseReady) "Cloud Firestore Node: Active" else "No internet profile. Offline LAN Mode Active",
                    color = Color.White.copy(alpha = 0.7f),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

@Composable
fun CCTVDeviceScreen(
    viewModel: DeviceViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    
    val deviceId by viewModel.deviceId.collectAsState()
    val pin by viewModel.pin.collectAsState()
    val isBroadcasting by viewModel.isBroadcasting.collectAsState()
    val sessionState by viewModel.broadcastSessionState.collectAsState()

    // Pulsating animation for the ON AIR indicator
    val transition = rememberInfiniteTransition(label = "Pulse")
    val scale by transition.animateFloat(
        initialValue = 0.8f,
        targetValue = 1.3f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "PulseScale"
    )

    // Dynamic camera and mic permission requests
    val neededPermissions = mutableListOf(
        Manifest.permission.CAMERA,
        Manifest.permission.RECORD_AUDIO
    ).apply {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            add(Manifest.permission.POST_NOTIFICATIONS)
        }
    }.toTypedArray()

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val cameraGranted = results[Manifest.permission.CAMERA] ?: false
        val micGranted = results[Manifest.permission.RECORD_AUDIO] ?: false
        if (cameraGranted && micGranted) {
            viewModel.toggleBroadcast(context)
        } else {
            Toast.makeText(context, "Camera & Audio recording permissions are mandatory.", Toast.LENGTH_LONG).show()
        }
    }

    Scaffold(
        topBar = {
            PremiumCCTVTopBar(title = "CCTV Device Broadcaster", onBack = onBack)
        },
        containerColor = MidnightGray
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
                .verticalScroll(androidx.compose.foundation.rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Live broadcast state banner
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .border(1.dp, if (isBroadcasting) NeonGreen.copy(alpha = 0.5f) else Color.Gray.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                    .background(if (isBroadcasting) NeonGreen.copy(alpha = 0.08f) else Color.White.copy(alpha = 0.02f))
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Box(
                            modifier = Modifier.size(16.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            if (isBroadcasting) {
                                Canvas(modifier = Modifier.fillMaxSize()) {
                                    drawCircle(
                                        color = NeonGreen.copy(alpha = 0.3f),
                                        radius = size.minDimension / 2 * scale
                                    )
                                    drawCircle(
                                        color = NeonGreen,
                                        radius = size.minDimension / 2 * 0.7f
                                    )
                                }
                            } else {
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .background(Color.Gray, CircleShape)
                                )
                            }
                        }
                        Text(
                            text = if (isBroadcasting) "ON THE AIR: BROADCASTING ACTIVE" else "IDLE: CAMERA OFFLINE",
                            color = if (isBroadcasting) NeonGreen else Color.Gray,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                    
                    if (isBroadcasting) {
                        Badge(containerColor = NeonGreen, contentColor = MidnightGray) {
                            Text(
                                text = if (sessionState.clientJoined) "1 LIVE VIEWER" else "WAITING VIEWER",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(2.dp)
                            )
                        }
                    }
                }
            }

            // Real-time camera capture viewport
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(280.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .border(2.dp, if (isBroadcasting) NeonTeal else Color.DarkGray, RoundedCornerShape(16.dp))
            ) {
                if (isBroadcasting) {
                    val activeTrack = CCTVForegroundService.activeVideoTrack
                    val eglContext = CCTVForegroundService.eglBase

                    if (activeTrack != null) {
                        WebRTCStreamPlayer(
                            videoTrack = activeTrack,
                            eglBase = eglContext,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(Color.Black),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                CircularProgressIndicator(color = NeonTeal, strokeWidth = 3.dp)
                                Text("Engaging hardware streams...", color = Color.Gray, fontSize = 12.sp)
                            }
                        }
                    }
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(DarkCardBg),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Icon(Icons.Default.VideocamOff, contentDescription = null, tint = Color.DarkGray, modifier = Modifier.size(56.dp))
                            Text("Camera stream deactivated", color = Color.Gray, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                            Text("Press 'Start Broadcasting' to activate CameraX", color = Color.Gray.copy(alpha = 0.7f), fontSize = 11.sp)
                        }
                    }
                }
            }

            // Connection Credentials Panels
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Device ID Block
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(DarkCardBg)
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("CCTV Device ID", color = Color.Gray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text(
                            text = deviceId,
                            color = NeonTeal,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.ExtraBold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    IconButton(
                        onClick = {
                            clipboardManager.setText(AnnotatedString(deviceId))
                            Toast.makeText(context, "Device ID copied to clipboard", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier
                            .background(Color.White.copy(alpha = 0.05f), CircleShape)
                            .testTag("copy_device_id_button")
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = "Copy ID", tint = Color.LightGray)
                    }
                }

                // PIN Block
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(DarkCardBg)
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Secret Connection PIN", color = Color.Gray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text(
                            text = pin,
                            color = NeonAmber,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.ExtraBold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    IconButton(
                        onClick = {
                            clipboardManager.setText(AnnotatedString(pin))
                            Toast.makeText(context, "PIN code copied", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier
                            .background(Color.White.copy(alpha = 0.05f), CircleShape)
                            .testTag("copy_pin_button")
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = "Copy PIN", tint = Color.LightGray)
                    }
                }
            }

            // Local telemetry stats panel
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Battery
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = DarkCardBg)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Default.BatteryChargingFull, "Battery", tint = NeonGreen, modifier = Modifier.size(16.dp))
                            Text("Battery Level", color = Color.Gray, fontSize = 11.sp)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("${sessionState.batteryPercentage}%", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    }
                }
                
                // Network
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = DarkCardBg)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Default.Wifi, "Network", tint = NeonTeal, modifier = Modifier.size(16.dp))
                            Text("Network Transport", color = Color.Gray, fontSize = 11.sp)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(sessionState.networkStatus, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Main Action Button
            Button(
                onClick = {
                    if (isBroadcasting) {
                        viewModel.toggleBroadcast(context)
                    } else {
                        // Request permissions prior to starting
                        permissionLauncher.launch(neededPermissions)
                    }
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isBroadcasting) CyberPunkRed else NeonTeal,
                    contentColor = MidnightGray
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .testTag("broadcast_action_button"),
                elevation = ButtonDefaults.buttonElevation(8.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = if (isBroadcasting) Icons.Default.PortableWifiOff else Icons.Default.Stream,
                        contentDescription = null,
                        modifier = Modifier.size(24.dp)
                    )
                    Text(
                        text = if (isBroadcasting) "STOP BROADCASTING STREAM" else "START BROADCASTING NOW",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                }
            }
        }
    }
}

@Composable
fun CCTVViewerScreen(
    viewModel: ViewerViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    
    val deviceIdInput by viewModel.deviceIdInput.collectAsState()
    val pinInput by viewModel.pinInput.collectAsState()
    val connectionState by viewModel.connectionState.collectAsState() // "disconnected", "connecting", "connected", "failed"
    val statusMessage by viewModel.statusMessage.collectAsState()
    val remoteBattery by viewModel.remoteBattery.collectAsState()
    val remoteNetwork by viewModel.remoteNetwork.collectAsState()
    val latency by viewModel.latency.collectAsState()
    val remoteVideoTrack by viewModel.remoteVideoTrack.collectAsState()

    var isFullscreen by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            if (!isFullscreen) {
                PremiumCCTVTopBar(
                    title = "Live Remote CCTV Viewer",
                    onBack = {
                        viewModel.disconnect()
                        onBack()
                    }
                )
            }
        },
        containerColor = MidnightGray
    ) { innerPadding ->
        
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(if (isFullscreen) PaddingValues(0.dp) else innerPadding)
        ) {
            if (connectionState != "connected") {
                // Setup / Credentials Entry Panel
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp)
                        .verticalScroll(androidx.compose.foundation.rememberScrollState()),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .background(NeonAmber.copy(alpha = 0.12f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Tv, contentDescription = null, tint = NeonAmber, modifier = Modifier.size(36.dp))
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    Text(
                        "Synchronize CCTV Stream",
                        color = Color.White,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        "Input room parameters of the target broadcasting phone.",
                        color = Color.Gray,
                        modifier = Modifier.padding(top = 4.dp),
                        textAlign = TextAlign.Center,
                        fontSize = 12.sp
                    )

                    Spacer(modifier = Modifier.height(28.dp))

                    // Fields
                    OutlinedTextField(
                        value = deviceIdInput,
                        onValueChange = { if (it.length <= 6) viewModel.setDeviceId(it) },
                        label = { Text("CCTV Device ID", color = Color.LightGray) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonAmber,
                            unfocusedBorderColor = Color.DarkGray,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("viewer_device_id_input"),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    OutlinedTextField(
                        value = pinInput,
                        onValueChange = { if (it.length <= 6) viewModel.setPin(it) },
                        label = { Text("6-Digit Connection PIN", color = Color.LightGray) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonAmber,
                            unfocusedBorderColor = Color.DarkGray,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("viewer_pin_input"),
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword)
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    if (statusMessage.isNotEmpty()) {
                        Text(
                            text = statusMessage,
                            color = if (connectionState == "failed") CyberPunkRed else NeonAmber,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(bottom = 16.dp),
                            textAlign = TextAlign.Center
                        )
                    }

                    Button(
                        onClick = { viewModel.connect(context) },
                        enabled = connectionState != "connecting",
                        colors = ButtonDefaults.buttonColors(
                            containerColor = NeonAmber,
                            contentColor = MidnightGray
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp)
                            .testTag("connect_viewer_button"),
                        elevation = ButtonDefaults.buttonElevation(8.dp)
                    ) {
                        if (connectionState == "connecting") {
                            CircularProgressIndicator(color = MidnightGray, modifier = Modifier.size(24.dp))
                        } else {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(Icons.Default.CastConnected, contentDescription = null)
                                Text("SECURE P2P CONNECTION", fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
                            }
                        }
                    }
                }
            } else {
                // Interactive CCTV Video Player View
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .clickable { isFullscreen = !isFullscreen } // Toggle full screen elements on tap!
                ) {
                    WebRTCStreamPlayer(
                        videoTrack = remoteVideoTrack,
                        eglBase = viewModel.eglBase,
                        modifier = Modifier.fillMaxSize()
                    )

                    // Overlay HUD - Top Section
                    AnimatedVisibility(
                        visible = !isFullscreen,
                        enter = fadeIn() + slideInVertically(),
                        exit = fadeOut() + slideOutVertically(),
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.TopCenter)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    Brush.verticalGradient(
                                        listOf(
                                            Color.Black.copy(alpha = 0.8f),
                                            Color.Transparent
                                        )
                                    )
                                )
                                .padding(20.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .background(NeonGreen, CircleShape)
                                )
                                Text(
                                    text = "LIVE FEED ACTIVE",
                                    color = Color.White,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            
                            Badge(containerColor = Color.White.copy(alpha = 0.15f)) {
                                Text(
                                    text = "ROOM: ${deviceIdInput}",
                                    color = NeonTeal,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(4.dp)
                                )
                            }
                        }
                    }

                    // Overlay HUD - Floating Stats Bottom Cards
                    AnimatedVisibility(
                        visible = !isFullscreen,
                        enter = fadeIn() + slideInVertically { it },
                        exit = fadeOut() + slideOutVertically { it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.BottomCenter)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    Brush.verticalGradient(
                                        listOf(
                                            Color.Transparent,
                                            Color.Black.copy(alpha = 0.85f)
                                        )
                                    )
                                )
                                .padding(20.dp),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            // Stats grid
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                // Battery Stat
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(Color.White.copy(alpha = 0.08f))
                                        .padding(12.dp)
                                ) {
                                    Column {
                                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                            Icon(Icons.Default.Battery4Bar, "Cam Battery", tint = NeonGreen, modifier = Modifier.size(14.dp))
                                            Text("Cam Battery", color = Color.LightGray, fontSize = 10.sp)
                                        }
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text("$remoteBattery%", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                    }
                                }

                                // Delay Latency Stat
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(Color.White.copy(alpha = 0.08f))
                                        .padding(12.dp)
                                ) {
                                    Column {
                                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                            Icon(Icons.Default.Speed, "UDP Latency", tint = NeonTeal, modifier = Modifier.size(14.dp))
                                            Text("P2P Delay", color = Color.LightGray, fontSize = 10.sp)
                                        }
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text("$latency ms", color = NeonTeal, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                    }
                                }

                                // Network Stat
                                Box(
                                    modifier = Modifier
                                        .weight(1.2f)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(Color.White.copy(alpha = 0.08f))
                                        .padding(12.dp)
                                ) {
                                    Column {
                                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                            Icon(Icons.Default.SignalCellularAlt, "Link Transport", tint = NeonGreen, modifier = Modifier.size(14.dp))
                                            Text("Link Quality", color = Color.LightGray, fontSize = 10.sp)
                                        }
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text("$remoteNetwork (Excellent)", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }

                            // Disconnect Button
                            Button(
                                onClick = { viewModel.disconnect() },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = CyberPunkRed,
                                    contentColor = Color.White
                                ),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(50.dp)
                                    .testTag("disconnect_viewer_button")
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(Icons.Default.CallEnd, contentDescription = null, modifier = Modifier.size(20.dp))
                                    Text("CLOSE SECURE STREAM", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                }
                            }
                        }
                    }

                    // Fullscreen tips helper
                    if (isFullscreen) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .padding(16.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color.Black.copy(alpha = 0.6f))
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text("TAP SCREEN TO RESTORE CONTROLS", color = Color.White.copy(alpha = 0.7f), fontSize = 10.sp, fontWeight = FontWeight.Medium)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun WebRTCStreamPlayer(
    videoTrack: VideoTrack?,
    eglBase: EglBase,
    modifier: Modifier = Modifier
) {
    if (videoTrack == null) {
        Box(
            modifier = modifier.background(Color.Black),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                CircularProgressIndicator(color = NeonTeal, strokeWidth = 3.dp)
                Text("Waiting for live session key frames...", color = Color.Gray, fontSize = 12.sp)
            }
        }
    } else {
        AndroidView(
            factory = { ctx ->
                SurfaceViewRenderer(ctx).apply {
                    init(eglBase.eglBaseContext, null)
                    setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FILL)
                    setMirror(false)
                    videoTrack.addSink(this)
                }
            },
            update = { _ ->
                // Automatically updates via native pipeline sinks
            },
            modifier = modifier,
            onRelease = { view ->
                try {
                    videoTrack.removeSink(view)
                    view.release()
                } catch (e: Exception) {
                    Log.e("CCTV_PLAYER", "SurfaceViewRenderer release exception: ${e.message}")
                }
            }
        )
    }
}
