package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Accent Lavender colors from styling
val CleanBg = Color(0xFFFDF8F8)
val DarkText = Color(0xFF1C1B1F)
val GrayText = Color(0xFF49454F)
val ActiveGray = Color(0xFFE6E1E5)

// Cards & accents
val PurpleCardBg = Color(0xFFEADDFF)
val PurpleCardText = Color(0xFF21005D)
val SurfaceVariant = Color(0xFFF3EDF7)
val BorderColor = Color(0xFFCAC4D0)

// Standard components
val Purple40 = Color(0xFF6750A4)
val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey40 = Color(0xFF625B71)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink40 = Color(0xFF7D5260)
val Pink80 = Color(0xFFEFB8C8)

// Action stop button
val DarkRed = Color(0xFF8C1D18)
val RedStopButton = Color(0xFFB3261E)
val LightBlueSdp = Color(0xFFD1E1FF)
val DarkBlueSdp = Color(0xFF001D35)
