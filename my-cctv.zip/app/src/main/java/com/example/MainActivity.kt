package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.example.firebase.FirebaseHelper
import com.example.ui.components.CCTVMasterApp
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.DeviceViewModel
import com.example.viewmodel.ViewerViewModel

class MainActivity : ComponentActivity() {
    
    private val deviceViewModel: DeviceViewModel by viewModels()
    private val viewerViewModel: ViewerViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Dynamic edge-to-edge fullscreen display
        enableEdgeToEdge()
        
        // Attempt programmatical Firebase configuration (gracefully falls back if no google-services is configured)
        FirebaseHelper.initialize(applicationContext)

        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = com.example.ui.components.MidnightGray
                ) {
                    CCTVMasterApp(
                        deviceViewModel = deviceViewModel,
                        viewerViewModel = viewerViewModel
                    )
                }
            }
        }
    }
}
