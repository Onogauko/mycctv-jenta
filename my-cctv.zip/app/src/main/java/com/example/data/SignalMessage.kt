package com.example.data

sealed class SignalMessage {
    data class Offer(val sdp: String) : SignalMessage()
    data class Answer(val sdp: String) : SignalMessage()
    data class IceCandidate(val sdp: String, val sdpMid: String, val sdpMLineIndex: Int) : SignalMessage()
}
