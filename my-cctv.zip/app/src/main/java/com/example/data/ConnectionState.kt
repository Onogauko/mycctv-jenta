package com.example.data

sealed class AppMode {
    object Idle : AppMode()
    object Device : AppMode()
    object Viewer : AppMode()
}

enum class StreamState {
    IDLE,
    PREPARING,
    STREAMING,
    ERROR
}

data class DeviceStatus(
    val deviceId: String = "",
    val pin: String = "",
    val online: Boolean = false,
    val batteryPercentage: Int = 100,
    val networkStatus: String = "Unknown",
    val sdpOffer: String? = null,
    val sdpAnswer: String? = null,
    val candidates: List<Map<String, Any>> = emptyList(),
    val viewerCandidates: List<Map<String, Any>> = emptyList(),
    val viewerConnected: Boolean = false,
    val lastActive: Long = 0L
)
