package com.example.data

data class SessionState(
    val deviceId: String = "",
    val pin: String = "",
    val status: String = "idle", // "idle", "streaming"
    val batteryPercentage: Int = 100,
    val networkStatus: String = "Online",
    val clientJoined: Boolean = false,
    val rtcOffer: String? = null,
    val rtcAnswer: String? = null,
    val lastUpdate: Long = 0L,
    val latency: Long = 0L
)

data class SignalingCandidate(
    val sdp: String = "",
    val sdpMid: String = "",
    val sdpMLineIndex: Int = 0,
    val serverUrl: String = ""
)
