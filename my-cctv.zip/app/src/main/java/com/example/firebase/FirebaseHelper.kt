package com.example.firebase

import android.content.Context
import android.util.Log
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

object FirebaseHelper {
    private const val TAG = "FirebaseHelper"
    private var isFirebaseInitialized = false

    fun initialize(context: Context): Boolean {
        if (isFirebaseInitialized) return true
        
        try {
            // Attempt to initialize using default options (e.g. from google-services.json)
            FirebaseApp.initializeApp(context)
            isFirebaseInitialized = true
            Log.d(TAG, "Firebase initialized via default credentials.")
            
            // Perform anonymous auth if needed
            FirebaseAuth.getInstance().signInAnonymously()
                .addOnSuccessListener {
                    Log.d(TAG, "Anonymous auth successful: ${it.user?.uid}")
                }
                .addOnFailureListener {
                    Log.w(TAG, "Anonymous auth failed: ${it.message}")
                }
            return true
        } catch (e: Exception) {
            Log.w(TAG, "Firebase automatic registration: No google-services.json found (${e.message}). Using LAN offline fallback.")
            isFirebaseInitialized = false
        }
        return false
    }

    fun isReady(): Boolean = isFirebaseInitialized

    fun getAuth(): FirebaseAuth? {
        return if (isFirebaseInitialized) FirebaseAuth.getInstance() else null
    }

    fun getFirestore(): FirebaseFirestore? {
        return if (isFirebaseInitialized) FirebaseFirestore.getInstance() else null
    }
}
