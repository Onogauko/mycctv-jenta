package com.example.firebase

import android.content.Context
import android.util.Log
import com.example.data.DeviceStatus
import com.example.data.SignalMessage
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.util.UUID

class SignalingClient(private val context: Context) {
    private val TAG = "SignalingClient"
    private var db: FirebaseFirestore? = null
    private var auth: FirebaseAuth? = null
    private var isFirebaseAvailable = false

    private val _incomingMessages = MutableSharedFlow<SignalMessage>(extraBufferCapacity = 50)
    val incomingMessages: SharedFlow<SignalMessage> = _incomingMessages

    private var deviceListenerRegistration: ListenerRegistration? = null

    // Local signaling loopback queue in case Firebase is not provisioned or offline
    companion object {
        private val localDeviceRegistry = mutableMapOf<String, DeviceStatus>()
        private val localListeners = mutableMapOf<String, (DeviceStatus) -> Unit>()

        fun registerLocalDevice(deviceId: String, status: DeviceStatus, onUpdate: (DeviceStatus) -> Unit) {
            localDeviceRegistry[deviceId] = status
            localListeners[deviceId] = onUpdate
        }

        fun updateLocalStatus(deviceId: String, status: DeviceStatus) {
            localDeviceRegistry[deviceId] = status
            localListeners[deviceId]?.invoke(status)
        }

        fun getLocalDevice(deviceId: String): DeviceStatus? = localDeviceRegistry[deviceId]

        fun notifyLocalUpdate(deviceId: String) {
            val status = localDeviceRegistry[deviceId]
            if (status != null) {
                localListeners[deviceId]?.invoke(status)
            }
        }
    }

    init {
        try {
            // Attempt to initialize Firebase if available
            if (FirebaseApp.getApps(context).isEmpty()) {
                FirebaseApp.initializeApp(context)
            }
            db = FirebaseFirestore.getInstance()
            auth = FirebaseAuth.getInstance()
            isFirebaseAvailable = true
            Log.d(TAG, "Firebase initialized successfully.")
        } catch (e: Exception) {
            Log.w(TAG, "Firebase initialization failed (No google-services.json). Using LAN local signaling fallback: ${e.message}")
            isFirebaseAvailable = false
        }
    }

    fun isAvailable(): Boolean = isFirebaseAvailable

    suspend fun authenticateAnonymously(): Boolean {
        if (!isFirebaseAvailable || auth == null) return true // Treat as success in mock mode
        return try {
            auth?.signInAnonymously()?.await()
            true
        } catch (e: Exception) {
            Log.e(TAG, "Anonymous auth failed: ${e.message}")
            false
        }
    }

    fun startDeviceSignaling(deviceId: String, initialStatus: DeviceStatus, onViewerOfferReceived: (String, List<Map<String, Any>>) -> Unit) {
        if (!isFirebaseAvailable || db == null) {
            // Register local simulated signaling
            registerLocalDevice(deviceId, initialStatus) { updatedStatus ->
                if (updatedStatus.sdpAnswer != null) {
                    CoroutineScope(Dispatchers.IO).launch {
                        _incomingMessages.emit(SignalMessage.Answer(updatedStatus.sdpAnswer))
                    }
                }
                if (updatedStatus.viewerCandidates.isNotEmpty()) {
                    CoroutineScope(Dispatchers.IO).launch {
                        updatedStatus.viewerCandidates.forEach { cand ->
                            val sdpMid = cand["sdpMid"] as? String ?: ""
                            val sdpMLineIndex = (cand["sdpMLineIndex"] as? Number)?.toInt() ?: 0
                            val candidate = cand["candidate"] as? String ?: ""
                            _incomingMessages.emit(SignalMessage.IceCandidate(candidate, sdpMid, sdpMLineIndex))
                        }
                    }
                }
            }
            return
        }

        try {
            val docRef = db!!.collection("cctv_devices").document(deviceId)
            docRef.set(initialStatus)

            deviceListenerRegistration = docRef.addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e(TAG, "Firestore listen failed: ${error.message}")
                    return@addSnapshotListener
                }
                if (snapshot != null && snapshot.exists()) {
                    val status = snapshot.toObject(DeviceStatus::class.java)
                    if (status != null) {
                        // If viewer provided an answer
                        status.sdpAnswer?.let { answer ->
                            CoroutineScope(Dispatchers.IO).launch {
                                _incomingMessages.emit(SignalMessage.Answer(answer))
                            }
                        }
                        // Map incoming ICE candidates from viewer
                        if (status.viewerCandidates.isNotEmpty()) {
                            CoroutineScope(Dispatchers.IO).launch {
                                status.viewerCandidates.forEach { cand ->
                                    val sdpMid = cand["sdpMid"] as? String ?: ""
                                    val sdpMLineIndex = (cand["sdpMLineIndex"] as? Number)?.toInt() ?: 0
                                    val candidate = cand["candidate"] as? String ?: ""
                                    _incomingMessages.emit(SignalMessage.IceCandidate(candidate, sdpMid, sdpMLineIndex))
                                }
                            }
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error starting device signaling: ${e.message}")
        }
    }

    fun updateDeviceStatus(deviceId: String, battery: Int, network: String, online: Boolean) {
        if (!isFirebaseAvailable || db == null) {
            val current = getLocalDevice(deviceId) ?: DeviceStatus(deviceId = deviceId)
            updateLocalStatus(deviceId, current.copy(batteryPercentage = battery, networkStatus = network, online = online))
            return
        }
        try {
            val docRef = db!!.collection("cctv_devices").document(deviceId)
            docRef.update(
                mapOf(
                    "batteryPercentage" to battery,
                    "networkStatus" to network,
                    "online" to online,
                    "lastActive" to System.currentTimeMillis()
                )
            )
        } catch (e: Exception) {
            Log.e(TAG, "Error updating battery & status in Firestore: ${e.message}")
        }
    }

    fun sendOfferAndCandidates(deviceId: String, sdpOffer: String, candidates: List<Map<String, Any>>) {
        if (!isFirebaseAvailable || db == null) {
            val current = getLocalDevice(deviceId) ?: DeviceStatus(deviceId = deviceId)
            updateLocalStatus(deviceId, current.copy(sdpOffer = sdpOffer, candidates = candidates))
            return
        }
        try {
            val docRef = db!!.collection("cctv_devices").document(deviceId)
            docRef.update(
                mapOf(
                    "sdpOffer" to sdpOffer,
                    "candidates" to candidates
                )
            )
        } catch (e: Exception) {
            Log.e(TAG, "Error updating offer inside Firestore: ${e.message}")
        }
    }

    fun stopDeviceSignaling(deviceId: String) {
        deviceListenerRegistration?.remove()
        if (!isFirebaseAvailable || db == null) return
        try {
            db!!.collection("cctv_devices").document(deviceId).update("online", false)
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping signaling: ${e.message}")
        }
    }

    // --- VIEWER SIDE ---
    fun listenToDevice(deviceId: String, pin: String, onDeviceStatusChanged: (DeviceStatus) -> Unit) {
        if (!isFirebaseAvailable || db == null) {
            val current = getLocalDevice(deviceId)
            if (current != null && current.pin == pin) {
                onDeviceStatusChanged(current)
                // Listen to updates
                registerLocalDevice(deviceId, current) { updated ->
                    if (updated.pin == pin) {
                        onDeviceStatusChanged(updated)
                    }
                }
            }
            return
        }

        try {
            val docRef = db!!.collection("cctv_devices").document(deviceId)
            deviceListenerRegistration = docRef.addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e(TAG, "Error listening to remote device: ${error.message}")
                    return@addSnapshotListener
                }
                if (snapshot != null && snapshot.exists()) {
                    val status = snapshot.toObject(DeviceStatus::class.java)
                    if (status != null && status.pin == pin) {
                        onDeviceStatusChanged(status)
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error adding device snapshot listener: ${e.message}")
        }
    }

    fun sendAnswer(deviceId: String, sdpAnswer: String, viewerCandidates: List<Map<String, Any>>) {
        if (!isFirebaseAvailable || db == null) {
            val current = getLocalDevice(deviceId) ?: DeviceStatus(deviceId = deviceId)
            updateLocalStatus(deviceId, current.copy(sdpAnswer = sdpAnswer, viewerCandidates = viewerCandidates, viewerConnected = true))
            return
        }
        try {
            val docRef = db!!.collection("cctv_devices").document(deviceId)
            docRef.update(
                mapOf(
                    "sdpAnswer" to sdpAnswer,
                    "viewerCandidates" to viewerCandidates,
                    "viewerConnected" to true
                )
            )
        } catch (e: Exception) {
            Log.e(TAG, "Error sending sdp answer in Firestore: ${e.message}")
        }
    }

    fun stopViewerSignaling() {
        deviceListenerRegistration?.remove()
    }
}
