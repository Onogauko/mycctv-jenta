package com.example.viewmodel

import android.content.Context
import android.content.Intent
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.SessionState
import com.example.service.CCTVForegroundService
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class DeviceViewModel : ViewModel() {

    private val _deviceId = MutableStateFlow("")
    val deviceId: StateFlow<String> = _deviceId

    private val _pin = MutableStateFlow("")
    val pin: StateFlow<String> = _pin

    private val _isBroadcasting = MutableStateFlow(false)
    val isBroadcasting: StateFlow<Boolean> = _isBroadcasting

    // Bridge the live service state (battery, client joined, network) straight to the compose screen
    val broadcastSessionState: StateFlow<SessionState> = CCTVForegroundService.serviceState

    init {
        generateNewRoomCredentials()
        monitorServiceRunningState()
    }

    fun generateNewRoomCredentials() {
        if (!_isBroadcasting.value) {
            _deviceId.value = (100000..999999).random().toString()
            _pin.value = (100000..999999).random().toString()
        }
    }

    private fun monitorServiceRunningState() {
        viewModelScope.launch {
            // Periodically check if the service is running (in case it is closed externally)
            while (true) {
                _isBroadcasting.value = CCTVForegroundService.isRunning
                if (CCTVForegroundService.isRunning) {
                    _deviceId.value = CCTVForegroundService.serviceState.value.deviceId
                    _pin.value = CCTVForegroundService.serviceState.value.pin
                }
                kotlinx.coroutines.delay(1000)
            }
        }
    }

    fun toggleBroadcast(context: Context) {
        val intent = Intent(context, CCTVForegroundService::class.java)
        if (_isBroadcasting.value) {
            intent.action = CCTVForegroundService.ACTION_STOP
            context.startService(intent)
            _isBroadcasting.value = false
        } else {
            intent.action = CCTVForegroundService.ACTION_START
            intent.putExtra(CCTVForegroundService.EXTRA_DEVICE_ID, _deviceId.value)
            intent.putExtra(CCTVForegroundService.EXTRA_PIN, _pin.value)
            context.startService(intent)
            _isBroadcasting.value = true
        }
    }
}
