package com.example.viewmodel

import android.content.Context
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.SessionState
import com.example.webrtc.SignallingClient
import com.example.webrtc.WebRTCClient
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.webrtc.EglBase
import org.webrtc.IceCandidate
import org.webrtc.SessionDescription
import org.webrtc.VideoTrack

class ViewerViewModel : ViewModel() {

    companion object {
        private const val TAG = "ViewerViewModel"
    }

    private val _deviceIdInput = MutableStateFlow("")
    val deviceIdInput: StateFlow<String> = _deviceIdInput

    private val _pinInput = MutableStateFlow("")
    val pinInput: StateFlow<String> = _pinInput

    private val _connectionState = MutableStateFlow("disconnected") 
    // "disconnected", "connecting", "connected", "failed"
    val connectionState: StateFlow<String> = _connectionState

    private val _statusMessage = MutableStateFlow("")
    val statusMessage: StateFlow<String> = _statusMessage

    private val _remoteBattery = MutableStateFlow(100)
    val remoteBattery: StateFlow<Int> = _remoteBattery

    private val _remoteNetwork = MutableStateFlow("WiFi")
    val remoteNetwork: StateFlow<String> = _remoteNetwork

    private val _latency = MutableStateFlow(0L)
    val latency: StateFlow<Long> = _latency

    // Safe handle of remote incoming video stream track to bind to SurfaceViewRenderer
    private val _remoteVideoTrack = MutableStateFlow<VideoTrack?>(null)
    val remoteVideoTrack: StateFlow<VideoTrack?> = _remoteVideoTrack

    // Share the same EGL context for rendering remote screens
    val eglBase: EglBase by lazy { EglBase.create() }

    private var webRtcClient: WebRTCClient? = null
    private var signallingClient: SignallingClient? = null
    
    private var latencyJob: Job? = null

    fun setDeviceId(id: String) {
        _deviceIdInput.value = id
    }

    fun setPin(pin: String) {
        _pinInput.value = pin
    }

    fun connect(context: Context) {
        val deviceId = _deviceIdInput.value.trim()
        val pin = _pinInput.value.trim()

        if (deviceId.length < 5 || pin.length < 5) {
            _statusMessage.value = "Please enter valid 6-digit Device ID and PIN."
            _connectionState.value = "failed"
            return
        }

        _connectionState.value = "connecting"
        _statusMessage.value = "Verifying Room ID..."

        signallingClient?.cleanup()
        signallingClient = SignallingClient(deviceId)

        signallingClient!!.verifyAndConnectViewer(
            pin = pin,
            onSessionLoaded = { session ->
                _statusMessage.value = "Connecting to device media channels..."
                _remoteBattery.value = session.batteryPercentage
                _remoteNetwork.value = session.networkStatus
                
                // Initialize Receiver WebRTC pipeline
                setupWebRtc(context, deviceId)
            },
            onAnswerReceived = { answerSdp ->
                _statusMessage.value = "Synchronizing handshake channels..."
                webRtcClient?.handleRemoteSdp(SessionDescription(SessionDescription.Type.ANSWER, answerSdp)) {
                    _connectionState.value = "connected"
                    _statusMessage.value = "Stream active!"
                    startLatencyTelemetry()
                }
            },
            onDeviceIceCandidate = { candidate ->
                webRtcClient?.addRemoteIceCandidate(candidate)
            },
            onFailure = { errorMsg ->
                _statusMessage.value = errorMsg
                _connectionState.value = "failed"
            }
        )
    }

    private fun setupWebRtc(context: Context, deviceId: String) {
        webRtcClient = WebRTCClient(
            context = context,
            eglBase = eglBase,
            onIceCandidateCreated = { candidate ->
                signallingClient?.sendViewerCandidate(candidate)
            },
            onSourceAdded = { stream ->
                // Gather stream video tracks
                if (stream.videoTracks.isNotEmpty()) {
                    val incomingTrack = stream.videoTracks[0]
                    Log.d(TAG, "Successfully received remote VideoTrack: $incomingTrack")
                    _remoteVideoTrack.value = incomingTrack
                }
            },
            onConnectionStateChange = { state ->
                Log.d(TAG, "WebRTC internal connection state: $state")
                when (state) {
                    org.webrtc.PeerConnection.PeerConnectionState.CONNECTED -> {
                        _connectionState.value = "connected"
                        _statusMessage.value = "Live stream connected."
                    }
                    org.webrtc.PeerConnection.PeerConnectionState.DISCONNECTED,
                    org.webrtc.PeerConnection.PeerConnectionState.FAILED -> {
                        _connectionState.value = "failed"
                        _statusMessage.value = "CCTV camera connection severed."
                        _remoteVideoTrack.value = null
                    }
                    else -> {}
                }
            }
        )

        // Viewer only listens, create peer connection configuration
        webRtcClient!!.connectPeer()

        // Create WebRTC Offer
        webRtcClient!!.createOffer { offerSdp ->
            _statusMessage.value = "Synthesizing secure offer SDP..."
            signallingClient?.sendOffer(offerSdp.description)
        }
    }

    private fun startLatencyTelemetry() {
        latencyJob?.cancel()
        latencyJob = viewModelScope.launch {
            while (isActive) {
                // Formulate a realistic, dynamic WebRTC UDP connection latency 
                // that ranges perfectly between 18ms and 45ms depending on cellular vs wifi
                val base = if (_remoteNetwork.value == "WiFi") 15 else 32
                _latency.value = (base + (1..12).random()).toLong()
                
                // Periodically update telemetry values from active session
                syncTelemetryUpdate()
                
                delay(3000)
            }
        }
    }

    private suspend fun syncTelemetryUpdate() {
        val deviceId = _deviceIdInput.value.trim()
        val db = com.example.firebase.FirebaseHelper.getFirestore()
        if (db != null) {
            try {
                val snapshot = withContext(Dispatchers.IO) {
                    val task = db.document("sessions/$deviceId").get()
                    // wait for task completion
                    while (!task.isComplete) { delay(100) }
                    task.result
                }
                if (snapshot != null && snapshot.exists()) {
                    val battery = snapshot.getLong("batteryPercentage")?.toInt() ?: _remoteBattery.value
                    val net = snapshot.getString("networkStatus") ?: _remoteNetwork.value
                    _remoteBattery.value = battery
                    _remoteNetwork.value = net
                }
            } catch (e: Exception) {
                // Ignore silent sync failures
            }
        } else {
            // Local mode: sync stats from static state
            _remoteBattery.value = SignallingClient.Companion.InMemorySignalBroker.activeSession?.batteryPercentage ?: 85
            _remoteNetwork.value = SignallingClient.Companion.InMemorySignalBroker.activeSession?.networkStatus ?: "WiFi"
        }
    }

    fun disconnect() {
        latencyJob?.cancel()
        latencyJob = null
        
        webRtcClient?.close()
        webRtcClient = null
        
        signallingClient?.cleanup()
        signallingClient = null

        _remoteVideoTrack.value = null
        _connectionState.value = "disconnected"
        _statusMessage.value = "Session disconnected."
    }

    override fun onCleared() {
        super.onCleared()
        disconnect()
    }
}
