package com.example.webrtc

import android.content.Context
import android.util.Log
import org.webrtc.*
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class WebRTCClient(
    private val context: Context,
    private val eglBase: EglBase,
    private val onIceCandidateCreated: (IceCandidate) -> Unit,
    private val onSourceAdded: (MediaStream) -> Unit = {},
    private val onConnectionStateChange: (PeerConnection.PeerConnectionState) -> Unit = {}
) {
    companion object {
        private const val TAG = "WebRTCClient"
    }

    private val executor: ExecutorService = Executors.newSingleThreadExecutor()
    private var peerConnectionFactory: PeerConnectionFactory? = null
    var peerConnection: PeerConnection? = null
    private var videoCapturer: VideoCapturer? = null
    private var videoSource: VideoSource? = null
    var videoTrack: VideoTrack? = null
    private var audioSource: AudioSource? = null
    var audioTrack: AudioTrack? = null
    private var surfaceTextureHelper: SurfaceTextureHelper? = null

    init {
        initPeerConnectionFactory()
    }

    private fun initPeerConnectionFactory() {
        val options = PeerConnectionFactory.InitializationOptions.builder(context)
            .setEnableInternalTracer(true)
            .createInitializationOptions()
        PeerConnectionFactory.initialize(options)

        val factoryBuilder = PeerConnectionFactory.builder()
            .setVideoDecoderFactory(DefaultVideoDecoderFactory(eglBase.eglBaseContext))
            .setVideoEncoderFactory(DefaultVideoEncoderFactory(eglBase.eglBaseContext, true, true))

        peerConnectionFactory = factoryBuilder.createPeerConnectionFactory()
        Log.d(TAG, "PeerConnectionFactory initialized.")
    }

    fun startLocalCapturer(previewRenderer: SurfaceViewRenderer) {
        executor.execute {
            val factory = peerConnectionFactory ?: return@execute
            val enumerator = Camera2Enumerator(context)
            val deviceNames = enumerator.deviceNames

            var backCamera: String? = null
            for (name in deviceNames) {
                if (enumerator.isBackFacing(name)) {
                    backCamera = name
                    break
                }
            }

            val targetCamera = backCamera ?: deviceNames.firstOrNull() ?: return@execute
            videoCapturer = enumerator.createCapturer(targetCamera, null)

            surfaceTextureHelper = SurfaceTextureHelper.create("CaptureThreadByCCTV", eglBase.eglBaseContext)
            videoSource = factory.createVideoSource(videoCapturer!!.isScreencast)

            videoCapturer!!.initialize(surfaceTextureHelper, context, videoSource!!.capturerObserver)
            videoCapturer!!.startCapture(1280, 720, 30)

            videoTrack = factory.createVideoTrack("CCTV_VIDEO_TRACK", videoSource)
            videoTrack?.addSink(previewRenderer)

            val audioConstraints = MediaConstraints()
            audioSource = factory.createAudioSource(audioConstraints)
            audioTrack = factory.createAudioTrack("CCTV_AUDIO_TRACK", audioSource)
            
            Log.d(TAG, "Local streams started.")
        }
    }

    fun connectPeer() {
        executor.execute {
            val factory = peerConnectionFactory ?: return@execute
            val iceServers = listOf(
                PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer(),
                PeerConnection.IceServer.builder("stun:stun1.l.google.com:19302").createIceServer(),
                PeerConnection.IceServer.builder("stun:stun2.l.google.com:19302").createIceServer()
            )

            val rtcConfig = PeerConnection.RTCConfiguration(iceServers).apply {
                sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
            }

            peerConnection = factory.createPeerConnection(rtcConfig, object : PeerConnection.Observer {
                override fun onSignalingChange(state: PeerConnection.SignalingState?) {}
                
                override fun onIceConnectionChange(state: PeerConnection.IceConnectionState?) {
                    Log.d(TAG, "ICE Connection Change: $state")
                }

                override fun onIceConnectionReceivingChange(receiving: Boolean) {}

                override fun onIceGatheringChange(state: PeerConnection.IceGatheringState?) {
                    Log.d(TAG, "ICE Gathering Change: $state")
                }

                override fun onIceCandidate(candidate: IceCandidate?) {
                    candidate?.let {
                        Log.d(TAG, "Local ICE Candidate gathered: ${it.sdp}")
                        onIceCandidateCreated(it)
                    }
                }

                override fun onIceCandidatesRemoved(candidates: Array<out IceCandidate>?) {}

                override fun onAddStream(stream: MediaStream?) {
                    stream?.let {
                        Log.d(TAG, "Remote stream added: ${it.id}")
                        onSourceAdded(it)
                    }
                }

                override fun onRemoveStream(stream: MediaStream?) {}

                override fun onDataChannel(channel: DataChannel?) {}

                override fun onRenegotiationNeeded() {}

                override fun onAddTrack(receiver: RtpReceiver?, mediaStreams: Array<out MediaStream>?) {
                    mediaStreams?.firstOrNull()?.let {
                        Log.d(TAG, "Remote track added in stream ${it.id}")
                        onSourceAdded(it)
                    }
                }

                override fun onConnectionChange(newState: PeerConnection.PeerConnectionState?) {
                    newState?.let {
                        Log.d(TAG, "Peer Connection overall state change: $it")
                        onConnectionStateChange(it)
                    }
                }
            })

            // If we are a local capturer, add local tracks to PeerConnection
            videoTrack?.let { peerConnection?.addTrack(it, listOf("ARDAMS")) }
            audioTrack?.let { peerConnection?.addTrack(it, listOf("ARDAMS")) }
            Log.d(TAG, "PeerConnection created and tracks attached.")
        }
    }

    fun createOffer(onSdpCreated: (SessionDescription) -> Unit) {
        executor.execute {
            val constraints = MediaConstraints().apply {
                mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveVideo", "true"))
                mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveAudio", "true"))
            }

            peerConnection?.createOffer(object : SdpObserver {
                override fun onCreateSuccess(desc: SessionDescription?) {
                    desc?.let {
                        peerConnection?.setLocalDescription(object : SdpObserver {
                            override fun onCreateSuccess(p0: SessionDescription?) {}
                            override fun onSetSuccess() {
                                Log.d(TAG, "Local Description set with Offer successfully.")
                                onSdpCreated(it)
                            }
                            override fun onCreateFailure(p0: String?) {}
                            override fun onSetFailure(p0: String?) {}
                        }, it)
                    }
                }
                override fun onSetSuccess() {}
                override fun onCreateFailure(error: String?) {
                    Log.e(TAG, "Offer creation failed: $error")
                }
                override fun onSetFailure(p0: String?) {}
            }, constraints)
        }
    }

    fun handleRemoteSdp(sdp: SessionDescription, onComplete: () -> Unit = {}) {
        executor.execute {
            peerConnection?.setRemoteDescription(object : SdpObserver {
                override fun onCreateSuccess(p0: SessionDescription?) {}
                override fun onSetSuccess() {
                    Log.d(TAG, "Remote Description set successfully.")
                    onComplete()
                }
                override fun onCreateFailure(p0: String?) {}
                override fun onSetFailure(error: String?) {
                    Log.e(TAG, "Remote Description setting failed: $error")
                }
            }, sdp)
        }
    }

    fun createAnswer(onSdpCreated: (SessionDescription) -> Unit) {
        executor.execute {
            val constraints = MediaConstraints().apply {
                mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveVideo", "true"))
                mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveAudio", "true"))
            }

            peerConnection?.createAnswer(object : SdpObserver {
                override fun onCreateSuccess(desc: SessionDescription?) {
                    desc?.let {
                        peerConnection?.setLocalDescription(object : SdpObserver {
                            override fun onCreateSuccess(p0: SessionDescription?) {}
                            override fun onSetSuccess() {
                                Log.d(TAG, "Local Description set with Answer successfully.")
                                onSdpCreated(it)
                            }
                            override fun onCreateFailure(p0: String?) {}
                            override fun onSetFailure(p0: String?) {}
                        }, it)
                    }
                }
                override fun onSetSuccess() {}
                override fun onCreateFailure(error: String?) {
                    Log.e(TAG, "Answer creation failed: $error")
                }
                override fun onSetFailure(p0: String?) {}
            }, constraints)
        }
    }

    fun addRemoteIceCandidate(candidate: IceCandidate) {
        executor.execute {
            peerConnection?.addIceCandidate(candidate)
            Log.d(TAG, "Added remote ICE candidate: ${candidate.sdp}")
        }
    }

    fun pauseVideo() {
        executor.execute {
            videoTrack?.setEnabled(false)
        }
    }

    fun resumeVideo() {
        executor.execute {
            videoTrack?.setEnabled(true)
        }
    }

    fun close() {
        executor.execute {
            try {
                videoCapturer?.stopCapture()
            } catch (e: Exception) {
                Log.e(TAG, "Error stopping video capture: ${e.message}")
            }
            videoCapturer?.dispose()
            videoSource?.dispose()
            surfaceTextureHelper?.dispose()
            audioSource?.dispose()
            
            peerConnection?.dispose()
            peerConnectionFactory?.dispose()
            Log.d(TAG, "WebRTC Client closed and resources disposed.")
        }
    }
}
