package com.example.webrtc

import android.util.Log
import com.example.data.SessionState
import com.example.firebase.FirebaseHelper
import com.google.firebase.firestore.ListenerRegistration
import org.webrtc.IceCandidate

class SignallingClient(
    private val deviceId: String
) {
    companion object {
        private const val TAG = "SignallingClient"
        
        // Single UI/process simulated Broker for easy local loopback test
        object InMemorySignalBroker {
            var activeSession: SessionState? = null
            var onDeviceOfferListener: ((String) -> Unit)? = null
            var onViewerAnswerListener: ((String) -> Unit)? = null
            var onDeviceCandidateListener: ((IceCandidate) -> Unit)? = null
            var onViewerCandidateListener: ((IceCandidate) -> Unit)? = null
        }
    }

    private val db = FirebaseHelper.getFirestore()
    private var sessionListener: ListenerRegistration? = null
    private var deviceCandidatesListener: ListenerRegistration? = null
    private var viewerCandidatesListener: ListenerRegistration? = null

    // BROADCASTER / DEVICE SIDE
    fun registerSession(
        pin: String,
        battery: Int,
        network: String,
        onOfferReceived: (String) -> Unit,
        onViewerIceCandidate: (IceCandidate) -> Unit
    ) {
        val path = "sessions/$deviceId"
        val state = SessionState(
            deviceId = deviceId,
            pin = pin,
            status = "streaming",
            batteryPercentage = battery,
            networkStatus = network,
            clientJoined = false,
            lastUpdate = System.currentTimeMillis()
        )

        if (db != null) {
            // Write session init to Firestore
            db.document(path).set(state)
                .addOnSuccessListener { Log.d(TAG, "CCTV Session initialized in Firestore.") }
                .addOnFailureListener { Log.e(TAG, "Firestore initialization failed: ${it.message}") }

            // Listen for offer SDP
            sessionListener = db.document(path).addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e(TAG, "Session update listening failed: ${error.message}")
                    return@addSnapshotListener
                }
                if (snapshot != null && snapshot.exists()) {
                    val offer = snapshot.getString("rtcOffer")
                    if (!offer.isNullOrEmpty()) {
                        Log.d(TAG, "SDP Offer received from Firestore viewer client.")
                        onOfferReceived(offer)
                    }
                }
            }

            // Listen for viewer ICE Candidates
            viewerCandidatesListener = db.collection("$path/viewerCandidates")
                .addSnapshotListener { snapshots, error ->
                    if (error != null) return@addSnapshotListener
                    snapshots?.let {
                        for (doc in it.documentChanges) {
                            if (doc.type == com.google.firebase.firestore.DocumentChange.Type.ADDED) {
                                val sdp = doc.document.getString("sdp") ?: ""
                                val sdpMid = doc.document.getString("sdpMid") ?: ""
                                val index = doc.document.getLong("sdpMLineIndex")?.toInt() ?: 0
                                onViewerIceCandidate(IceCandidate(sdpMid, index, sdp))
                            }
                        }
                    }
                }
        } else {
            // Memory/Simulated Mode
            InMemorySignalBroker.activeSession = state
            InMemorySignalBroker.onDeviceOfferListener = onOfferReceived
            InMemorySignalBroker.onViewerCandidateListener = onViewerIceCandidate
            Log.d(TAG, "[Offline Mode] CCTV Session registered in memory.")
        }
    }

    fun sendAnswer(answerSdp: String) {
        val path = "sessions/$deviceId"
        if (db != null) {
            db.document(path).update("rtcAnswer", answerSdp)
                .addOnSuccessListener { Log.d(TAG, "SDP Answer written to Firestore.") }
        } else {
            val session = InMemorySignalBroker.activeSession ?: return
            InMemorySignalBroker.activeSession = session.copy(rtcAnswer = answerSdp)
            InMemorySignalBroker.onViewerAnswerListener?.invoke(answerSdp)
            Log.d(TAG, "[Offline Mode] SDP Answer set in memory.")
        }
    }

    fun sendDeviceCandidate(candidate: IceCandidate) {
        val path = "sessions/$deviceId"
        if (db != null) {
            val candidateMap = mapOf(
                "sdp" to candidate.sdp,
                "sdpMid" to candidate.sdpMid,
                "sdpMLineIndex" to candidate.sdpMLineIndex
            )
            db.collection("$path/deviceCandidates").add(candidateMap)
                .addOnSuccessListener { Log.d(TAG, "Device candidate sent to Firestore.") }
        } else {
            InMemorySignalBroker.onDeviceCandidateListener?.invoke(candidate)
        }
    }

    // RECEIVER / CLIENT SIDE
    fun verifyAndConnectViewer(
        pin: String,
        onSessionLoaded: (SessionState) -> Unit,
        onAnswerReceived: (String) -> Unit,
        onDeviceIceCandidate: (IceCandidate) -> Unit,
        onFailure: (String) -> Unit
    ) {
        val path = "sessions/$deviceId"
        if (db != null) {
            db.document(path).get()
                .addOnSuccessListener { snapshot ->
                    if (snapshot != null && snapshot.exists()) {
                        val session = snapshot.toObject(SessionState::class.java)
                        if (session != null) {
                            if (session.status != "streaming") {
                                onFailure("CCTV Device is currently offline.")
                                return@addOnSuccessListener
                            }
                            if (session.pin != pin) {
                                onFailure("Incorrect connection PIN.")
                                return@addOnSuccessListener
                            }
                            // Valid CCTV connection!
                            onSessionLoaded(session)
                            
                            // Let Firestore know client joined
                            db.document(path).update("clientJoined", true)

                            // Start listening for Answer SDP
                            sessionListener = db.document(path).addSnapshotListener { syncSnap, error ->
                                if (error != null) return@addSnapshotListener
                                syncSnap?.let {
                                    val answerSdp = it.getString("rtcAnswer")
                                    if (!answerSdp.isNullOrEmpty()) {
                                        onAnswerReceived(answerSdp)
                                    }
                                }
                            }

                            // Start listening to device candidates
                            deviceCandidatesListener = db.collection("$path/deviceCandidates")
                                .addSnapshotListener { snapshots, error ->
                                    if (error != null) return@addSnapshotListener
                                    snapshots?.let {
                                        for (doc in it.documentChanges) {
                                            if (doc.type == com.google.firebase.firestore.DocumentChange.Type.ADDED) {
                                                val sdp = doc.document.getString("sdp") ?: ""
                                                val sdpMid = doc.document.getString("sdpMid") ?: ""
                                                val index = doc.document.getLong("sdpMLineIndex")?.toInt() ?: 0
                                                onDeviceIceCandidate(IceCandidate(sdpMid, index, sdp))
                                            }
                                        }
                                    }
                                }
                        } else {
                            onFailure("Failed to decrypt device session state.")
                        }
                    } else {
                        onFailure("CCTV Device ID not found.")
                    }
                }
                .addOnFailureListener {
                    onFailure("Firebase integration failure: ${it.message}")
                }
        } else {
            // Memory/Simulated Mode Handshake
            val session = InMemorySignalBroker.activeSession
            if (session != null) {
                if (session.status != "streaming") {
                    onFailure("CCTV Device is offline.")
                    return
                }
                if (session.pin != pin) {
                    onFailure("Incorrect connection PIN.")
                    return
                }
                onSessionLoaded(session)
                
                // Set memory answer listener
                InMemorySignalBroker.onViewerAnswerListener = onAnswerReceived
                InMemorySignalBroker.onDeviceCandidateListener = onDeviceIceCandidate
                Log.d(TAG, "[Offline Mode] Viewer verified and connected to in-memory session.")
            } else {
                onFailure("[Offline Mode] CCTV Device not streaming yet. Start device stream first!")
            }
        }
    }

    fun sendOffer(offerSdp: String) {
        val path = "sessions/$deviceId"
        if (db != null) {
            db.document(path).update("rtcOffer", offerSdp)
                .addOnSuccessListener { Log.d(TAG, "SDP Offer written to Firestore.") }
        } else {
            val session = InMemorySignalBroker.activeSession ?: return
            InMemorySignalBroker.activeSession = session.copy(rtcOffer = offerSdp)
            InMemorySignalBroker.onDeviceOfferListener?.invoke(offerSdp)
            Log.d(TAG, "[Offline Mode] SDP Offer set in memory.")
        }
    }

    fun sendViewerCandidate(candidate: IceCandidate) {
        val path = "sessions/$deviceId"
        if (db != null) {
            val candidateMap = mapOf(
                "sdp" to candidate.sdp,
                "sdpMid" to candidate.sdpMid,
                "sdpMLineIndex" to candidate.sdpMLineIndex
            )
            db.collection("$path/viewerCandidates").add(candidateMap)
                .addOnSuccessListener { Log.d(TAG, "Viewer Candidate written to Firestore.") }
        } else {
            InMemorySignalBroker.onViewerCandidateListener?.invoke(candidate)
        }
    }

    fun cleanup() {
        sessionListener?.remove()
        deviceCandidatesListener?.remove()
        viewerCandidatesListener?.remove()

        if (db != null) {
            val path = "sessions/$deviceId"
            db.document(path).delete()
            db.collection("$path/deviceCandidates").get().addOnSuccessListener { snaps ->
                for (doc in snaps) {
                    doc.reference.delete()
                }
            }
            db.collection("$path/viewerCandidates").get().addOnSuccessListener { snaps ->
                for (doc in snaps) {
                    doc.reference.delete()
                }
            }
        } else {
            InMemorySignalBroker.activeSession = null
            InMemorySignalBroker.onDeviceOfferListener = null
            InMemorySignalBroker.onViewerAnswerListener = null
            InMemorySignalBroker.onDeviceCandidateListener = null
            InMemorySignalBroker.onViewerCandidateListener = null
        }
    }
}
