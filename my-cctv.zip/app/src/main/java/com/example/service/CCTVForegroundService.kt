package com.example.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.data.SessionState
import com.example.webrtc.SignallingClient
import com.example.webrtc.WebRTCClient
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.webrtc.EglBase
import org.webrtc.IceCandidate
import org.webrtc.SessionDescription
import org.webrtc.VideoTrack

class CCTVForegroundService : Service() {

    companion object {
        private const val TAG = "CCTVService"
        private const val CHANNEL_ID = "CCTV_STREAM_CHANNEL"
        private const val NOTIFICATION_ID = 1012

        const val ACTION_START = "ACTION_START_STREAM"
        const val ACTION_STOP = "ACTION_STOP_STREAM"
        
        const val EXTRA_DEVICE_ID = "EXTRA_DEVICE_ID"
        const val EXTRA_PIN = "EXTRA_PIN"

        // State flows for the UI to observe live
        private val _serviceState = MutableStateFlow(SessionState())
        val serviceState: StateFlow<SessionState> = _serviceState

        @Volatile
        var isRunning: Boolean = false
            private set

        @Volatile
        var activeWebRtcClient: WebRTCClient? = null
            private set

        // Allows Compose live view to bind to actual camera output
        @Volatile
        var activeVideoTrack: VideoTrack? = null
            private set
            
        // Track the static EGL context for rendering
        val eglBase: EglBase by lazy { EglBase.create() }
    }

    private val serviceScope = CoroutineScope(Dispatchers.Main + Job())
    private var signallingClient: SignallingClient? = null
    private var telemetryJob: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action ?: return START_NOT_STICKY

        if (action == ACTION_STOP) {
            stopStreamingService()
            return START_NOT_STICKY
        }

        if (action == ACTION_START) {
            val deviceId = intent.getStringExtra(EXTRA_DEVICE_ID) ?: "000000"
            val pin = intent.getStringExtra(EXTRA_PIN) ?: "123456"
            startStreamingService(deviceId, pin)
        }

        return START_STICKY
    }

    private fun startStreamingService(deviceId: String, pin: String) {
        // Build foreground notification
        val notification = buildNotification(deviceId, "Offline (Pending Initialization)")
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            // Include camera and microphone types for API 29+
            var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            }
            startForeground(NOTIFICATION_ID, notification, type)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        // Initialize WebRTC
        val client = WebRTCClient(
            context = this,
            eglBase = eglBase,
            onIceCandidateCreated = { candidate ->
                signallingClient?.sendDeviceCandidate(candidate)
            },
            onSourceAdded = { stream ->
                // Devices do not receive streams, they only broadcast
            },
            onConnectionStateChange = { state ->
                Log.d(TAG, "Connection state changed: $state")
                _serviceState.value = _serviceState.value.copy(
                    clientJoined = (state == org.webrtc.PeerConnection.PeerConnectionState.CONNECTED ||
                                   state == org.webrtc.PeerConnection.PeerConnectionState.CONNECTING)
                )
            }
        )
        activeWebRtcClient = client

        // Setup Signaling
        signallingClient = SignallingClient(deviceId).apply {
            val battery = getBatteryPercentage()
            val netInfo = getNetworkStatus()
            
            _serviceState.value = SessionState(
                deviceId = deviceId,
                pin = pin,
                status = "streaming",
                batteryPercentage = battery,
                networkStatus = netInfo
            )

            // Start locally capturing WebRTC stream (with UI fallback)
            // Note: Camera starts capturing and feeding the WebRTC track
            client.startLocalCapturer(object : org.webrtc.SurfaceViewRenderer(this@CCTVForegroundService) {
                // Mock Surface Renderer to capture without layout requirement
            })

            // Store handle to video track once initialized inside executor
            serviceScope.launch {
                delay(1200) // Give WebRTC client enough time to initiate tracks
                activeVideoTrack = client.videoTrack
                Log.d(TAG, "Exposed active video track: $activeVideoTrack")
            }

            registerSession(
                pin = pin,
                battery = battery,
                network = netInfo,
                onOfferReceived = { offerSdp ->
                    client.connectPeer()
                    client.handleRemoteSdp(SessionDescription(SessionDescription.Type.OFFER, offerSdp)) {
                        client.createAnswer { answerSdp ->
                            sendAnswer(answerSdp.description)
                        }
                    }
                },
                onViewerIceCandidate = { viewerCandidate ->
                    client.addRemoteIceCandidate(viewerCandidate)
                }
            )
        }

        // Periodically update battery and network telemetry
        telemetryJob = serviceScope.launch {
            while (isActive) {
                delay(10000) // Emit every 10 seconds
                updateTelemetry(deviceId, pin)
            }
        }
    }

    private fun updateTelemetry(deviceId: String, pin: String) {
        val battery = getBatteryPercentage()
        val netInfo = getNetworkStatus()
        
        _serviceState.value = _serviceState.value.copy(
            batteryPercentage = battery,
            networkStatus = netInfo
        )

        // Sync with signaling server if in firestore mode
        val manager = signallingClient
        if (manager != null) {
            val db = com.example.firebase.FirebaseHelper.getFirestore()
            if (db != null) {
                db.document("sessions/$deviceId").update(
                    "batteryPercentage", battery,
                    "networkStatus", netInfo,
                    "lastUpdate", System.currentTimeMillis()
                )
            }
        }

        // Update active notification text
        val title = "My CCTV Broadcasting Room: $deviceId"
        val desc = "Battery $battery%  |  Network: $netInfo"
        val managerNotification = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        managerNotification.notify(NOTIFICATION_ID, buildNotification(deviceId, desc))
    }

    private fun getBatteryPercentage(): Int {
        val bm = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        return bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
    }

    private fun getNetworkStatus(): String {
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val capabilities = connectivityManager.getNetworkCapabilities(connectivityManager.activeNetwork) ?: return "Offline"
        return when {
            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "WiFi"
            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Cellular"
            else -> "Online"
        }
    }

    private fun buildNotification(deviceId: String, content: String): Notification {
        val stopIntent = Intent(this, CCTVForegroundService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this, 0, stopIntent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("My CCTV is active")
            .setContentText("Room ID: $deviceId ($content)")
            .setSmallIcon(android.R.drawable.presence_video_online)
            .setOngoing(true)
            .setCategory(Notification.CATEGORY_SERVICE)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop Broadcasting", stopPendingIntent)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "CCTV Stream Notification",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Keeps CCTV device stream functioning in background"
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    private fun stopStreamingService() {
        Log.d(TAG, "Requesting service destruction.")
        stopSelf()
    }

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        telemetryJob?.cancel()
        serviceScope.cancel()

        activeWebRtcClient?.close()
        activeWebRtcClient = null
        activeVideoTrack = null

        signallingClient?.cleanup()
        signallingClient = null

        _serviceState.value = SessionState()
        Log.d(TAG, "Service destroyed, video stream closed cleanly.")
    }
}
