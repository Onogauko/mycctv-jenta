package com.example.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.data.DeviceStatus
import com.example.firebase.SignalingClient
import com.example.webrtc.WebRtcClient
import kotlinx.coroutines.*
import org.webrtc.IceCandidate
import org.webrtc.SessionDescription
import java.util.UUID

class CctvService : Service() {
    private val TAG = "CctvService"
    private val NOTIFICATION_ID = 1012
    private val CHANNEL_ID = "cctv_streaming_channel"

    private val binder = LocalBinder()
    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    var deviceId: String = ""
        private set
    var pin: String = ""
        private set

    var webRtcClient: WebRtcClient? = null
        private set
    private var signalingClient: SignalingClient? = null
    
    private var isStreaming = false
    private val candidatesToSend = mutableListOf<Map<String, Any>>()

    inner class LocalBinder : Binder() {
        fun getService(): CctvService = this@CctvService
    }

    override fun onCreate() {
        super.onCreate()
        deviceId = loadOrCreateDeviceId()
        pin = generate6DigitPin()
        createNotificationChannel()
        signalingClient = SignalingClient(applicationContext)
    }

    override fun onBind(intent: Intent): IBinder {
        return binder
    }

    private fun loadOrCreateDeviceId(): String {
        val sharedPrefs = getSharedPreferences("my_cctv_prefs", Context.MODE_PRIVATE)
        var id = sharedPrefs.getString("device_id", "")
        if (id.isNullOrEmpty()) {
            id = "CAM-" + (1000 + (Math.random() * 9000).toInt()) + "-" + UUID.randomUUID().toString().take(2).uppercase()
            sharedPrefs.edit().putString("device_id", id).apply()
        }
        return id
    }

    private fun generate6DigitPin(): String {
        val randomNum = (100000 + (Math.random() * 900000).toInt())
        return randomNum.toString()
    }

    fun startStreaming(onStatusUpdate: () -> Unit) {
        if (isStreaming) return
        isStreaming = true

        // 1. Initialized WebRTC media
        webRtcClient = WebRtcClient(
            context = applicationContext,
            onIceCandidateCreated = { candidate ->
                sendIceCandidate(candidate)
            },
            onSdpCreated = { sdp ->
                sendSdpOffer(sdp)
            },
            onRemoteStreamAdded = { _, _ ->
                Log.d(TAG, "Viewer side stream changed")
            }
        )

        webRtcClient?.initMediaSources()

        // 2. Start Signaling via Firestore / Fallback
        val initialStatus = DeviceStatus(
            deviceId = deviceId,
            pin = pin,
            online = true,
            batteryPercentage = getBatteryPercentage(),
            networkStatus = "Stable",
            lastActive = System.currentTimeMillis()
        )

        signalingClient?.startDeviceSignaling(deviceId, initialStatus) { viewerOffer, viewerCandidates ->
            // In cctv device mode, the cctv device usually acts as the caller making the offer, 
            // or we negotiate when viewer connects. Here we can generate offer, upload it and wait for answer!
        }

        // Start listening to peer signals
        serviceScope.launch {
            signalingClient?.incomingMessages?.collect { msg ->
                when (msg) {
                    is com.example.data.SignalMessage.Answer -> {
                        Log.d(TAG, "Received SDP answer, setting remote description...")
                        webRtcClient?.handleRemoteSdp(msg.sdp, isOffer = false)
                    }
                    is com.example.data.SignalMessage.IceCandidate -> {
                        Log.d(TAG, "Received Remote ICE Candidate, injecting...")
                        webRtcClient?.addRemoteIceCandidate(
                            IceCandidate(msg.sdpMid, msg.sdpMLineIndex, msg.sdp)
                        )
                    }
                    else -> {}
                }
            }
        }

        // Create the initial WebRTC Offer
        webRtcClient?.createOffer()

        // Start background status updates (battery, network status report once in a while)
        startStatusReporting()

        // Show Foreground Notification
        val notification = buildStreamingNotification("Active Stream", "Your camera feed is live on ID: $deviceId")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID, 
                notification, 
                /* camera & microphone are captured */
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA or 
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
        
        onStatusUpdate()
    }

    fun stopStreaming(onStatusUpdate: () -> Unit) {
        if (!isStreaming) return
        isStreaming = false
        
        stopStatusReporting()
        signalingClient?.stopDeviceSignaling(deviceId)
        webRtcClient?.dispose()
        webRtcClient = null
        
        stopForeground(true)
        onStatusUpdate()
    }

    private var statusJob: Job? = null
    private fun startStatusReporting() {
        statusJob = serviceScope.launch {
            while (isActive) {
                signalingClient?.updateDeviceStatus(
                    deviceId = deviceId,
                    battery = getBatteryPercentage(),
                    network = "Stable",
                    online = true
                )
                delay(10000) // update status every 10 seconds
            }
        }
    }

    private fun stopStatusReporting() {
        statusJob?.cancel()
        statusJob = null
    }

    private fun getBatteryPercentage(): Int {
        val batteryStatus: Intent? = IntentFilter(Intent.ACTION_BATTERY_CHANGED).let { filter ->
            applicationContext.registerReceiver(null, filter)
        }
        val level: Int = batteryStatus?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale: Int = batteryStatus?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        return if (level >= 0 && scale > 0) {
            ((level / scale.toFloat()) * 100).toInt()
        } else {
            100
        }
    }

    private fun sendSdpOffer(sdp: SessionDescription) {
        val convertedCandidates = candidatesToSend.toList()
        signalingClient?.sendOfferAndCandidates(deviceId, sdp.description, convertedCandidates)
    }

    private fun sendIceCandidate(candidate: IceCandidate) {
        val map = mapOf(
            "sdpMid" to candidate.sdpMid,
            "sdpMLineIndex" to candidate.sdpMLineIndex,
            "candidate" to candidate.sdp
        )
        candidatesToSend.add(map)
        
        // If we already set the SdpOffer, trigger updating on the signaling server right away
        webRtcClient?.rootEglBase?.let {
            val convertedCandidates = candidatesToSend.toList()
            signalingClient?.sendOfferAndCandidates(deviceId, "pending", convertedCandidates)
        }
    }

    private fun buildStreamingNotification(title: String, text: String): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(text)
            .setSmallIcon(android.R.drawable.presence_video_online)
            .setOngoing(true)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val serviceChannel = NotificationChannel(
                CHANNEL_ID,
                "CCTV Streaming Status",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(serviceChannel)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
        webRtcClient?.dispose()
        signalingClient?.stopDeviceSignaling(deviceId)
    }
}
