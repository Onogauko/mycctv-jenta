package com.example.util

import androidx.camera.core.ImageProxy
import java.nio.ByteBuffer

object YuvToNv21 {
    fun convertYUV420888ToNV21(image: ImageProxy): ByteArray {
        val yPlane = image.planes[0]
        val uPlane = image.planes[1]
        val vPlane = image.planes[2]

        val yBuffer = yPlane.buffer
        val uBuffer = uPlane.buffer
        val vBuffer = vPlane.buffer

        val ySize = yBuffer.remaining()
        val uSize = uBuffer.remaining()
        val vSize = vBuffer.remaining()

        val nv21 = ByteArray(ySize + uSize + vSize)

        // Duplicate buffers so we do not distort current state
        val yDuplicated = yBuffer.duplicate()
        val uDuplicated = uBuffer.duplicate()
        val vDuplicated = vBuffer.duplicate()

        yDuplicated.get(nv21, 0, ySize)

        // For NV21, the UV plane contains V and U interleaved (V first, then U).
        val pixelStride = uPlane.pixelStride
        val rowStride = uPlane.rowStride
        
        var uvOffset = ySize
        
        // Quick and robust fallback for standard interleaving
        if (pixelStride == 2) {
            // V is usually first in NV21
            vDuplicated.get(nv21, uvOffset, vSize)
        } else {
            // Manually interleave U and V plane data
            val uBytes = ByteArray(uSize)
            val vBytes = ByteArray(vSize)
            uDuplicated.get(uBytes)
            vDuplicated.get(vBytes)
            
            for (i in 0 until uSize) {
                if (uvOffset < nv21.size) {
                    nv21[uvOffset++] = vBytes[i]
                }
                if (uvOffset < nv21.size) {
                    nv21[uvOffset++] = uBytes[i]
                }
            }
        }
        return nv21
    }
}
